# Let's Try 2 - Unit 7 - Let's make a pizza

## Play

You should be able to build your pizza at <https://altivities.earthiverse.ca/pizza/>

## About

This is a simple "game" that you can use on a tablet (e.g. iPad) to make a pizza.

The pizza base and most topping images are from the `Let's  Try 2` worksheets.

The broccoli and shrimp are from the `New Horizon Elementary` textbook.

Onions and bacon are edited from free illustrations found online.
